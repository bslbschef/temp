1.使用Raspberry Pi OS Desktop Version(自带Python3以及GPIO库和串口库)
2.启动ssh-service并设置开机自启动，查看IP并使用xshell登录
3.安装vim
2.开启硬件USB串口（若使用usb的话就不用了）
.新建文件夹yyuav与dataio
    (1)sudo mkdir /usr/local/uav/data
    (2)sudo mkdir /usr/local/uav/data/dataio
