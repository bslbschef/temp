from multiprocessing import Pipe
from multiprocessing.connection import Connection


def singleton(cls, *args, **kw):
    instances = {}

    def getinstance():
        if cls not in instances:
            instances[cls] = cls(*args, **kw)
        return instances[cls]
    return getinstance


@singleton
class PipeManager:
    def __init__(self) -> None:
        self._camera_parent, self._camera_child = Pipe()
        self._input_detector_parent, self._input_detector_child = Pipe()
        self._anemometer_parent, self._anemometer_child = Pipe()
        self._compass_parent, self._compass_child = Pipe()
        self._thermometer_parent, self._thermometer_child = Pipe()
        self._laser_controller_parent, self._laser_controller_child = Pipe()

    @property
    def camera_parent(self) -> Connection:
        return self._camera_parent

    @property
    def camera_child(self) -> Connection:
        return self._camera_child

    @property
    def input_detector_parent(self) -> Connection:
        return self._input_detector_parent

    @property
    def input_detector_child(self) -> Connection:
        return self._input_detector_child

    @property
    def anemometer_parent(self) -> Connection:
        return self._anemometer_parent

    @property
    def anemometer_child(self) -> Connection:
        return self._anemometer_child

    @property
    def compass_parent(self) -> Connection:
        return self._compass_parent

    @property
    def compass_child(self) -> Connection:
        return self._compass_child

    @property
    def thermometer_parent(self) -> Connection:
        return self._thermometer_parent

    @property
    def thermometer_child(self) -> Connection:
        return self._thermometer_child

    @property
    def laser_controller_parent(self) -> Connection:
        return self._laser_controller_parent

    @property
    def laser_controller_child(self) -> Connection:
        return self._laser_controller_child

    @property
    def all_parents(self):
        return (
            self._input_detector_parent,
            self._camera_parent,
            self._anemometer_parent,
            self._compass_parent,
            self._thermometer_parent,
            self._laser_controller_parent
        )

    @property
    def all_parents_without_input_detector(self):
        return (
            self._camera_parent,
            self._anemometer_parent,
            self._compass_parent,
            self._thermometer_parent,
            self._laser_controller_parent
        )
