from abc import ABCMeta, abstractclassmethod


class Subscriber(metaclass=ABCMeta):
    @abstractclassmethod
    def update(self):
        pass


class Publisher(object):
    def __init__(self) -> None:
        self.__subscribers = []
        self.__last_message = None

    def attach(self, subscriber: Subscriber) -> None:
        self.__subscribers.append(subscriber)

    def notify_subscribers(self) -> None:
        for sub in self.__subscribers:
            sub.update()

    def add_message(self, news) -> None:
        self.__last_message = news

    def get_message(self):
        return self.__last_message
