import logging
from abc import ABCMeta, abstractmethod
from multiprocessing import Process
from multiprocessing.connection import Connection

from utils.system_message_util import SystemMessageUtil, SystemOperationType


class BaseService(Process, metaclass=ABCMeta):
    def __init__(self, connection: Connection) -> None:
        super().__init__()
        self.__connection = connection

    @property
    def connection(self):
        return self.__connection

    @abstractmethod
    def start_work(self):
        pass

    @abstractmethod
    def stop_work(self):
        pass

    @abstractmethod
    def wait_work_done(self):
        pass

    def run(self) -> None:
        logging.info(f'Service {self.name} begin to run...')
        while True:
            msg = self.__connection.recv()
            operation_type = SystemMessageUtil.get_operation_type(msg)
            if operation_type == SystemOperationType.START:
                self.start_work()
            elif operation_type == SystemOperationType.STOP:
                self.stop_work()
            elif operation_type == SystemOperationType.QUIT:
                self.stop_work()
                break
            else:
                logging.warn(f'unkown operation type: {msg}')

        self.wait_work_done()
        logging.info(f'Service {self.name} complete to run...')
