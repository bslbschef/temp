from anemometer.anemometerservice import AnemometerService
from digitalcompass.digitalcompassservice import CompassService
from inputdetector.inputdetectorservice import InputDetectorService
from pipemanager import PipeManager
from utils.system_message_util import SystemMessageUtil


def singleton(cls, *args, **kw):
    instances = {}

    def getinstance():
        if cls not in instances:
            instances[cls] = cls(*args, **kw)
        return instances[cls]
    return getinstance


@singleton
class ServiceManager(object):
    def __init__(self) -> None:
        self._input_detector_service = InputDetectorService(
            PipeManager().input_detector_child
        )
        self._anemometer_service = AnemometerService(
            PipeManager().anemometer_child
        )
        self._compass_service = CompassService(
            PipeManager().compass_child
        )

    def initialize_all_services(self) -> None:
        self._input_detector_service.start()
        self._anemometer_service.start()
        self._compass_service.start()

    def start_input_detector(self) -> None:
        PipeManager().input_detector_parent.send(
            SystemMessageUtil.compose_start()
        )

    def start_all_without_input_detector(self) -> None:
        msg = SystemMessageUtil.compose_start()
        for connection in PipeManager().all_parents_without_input_detector:
            connection.send(msg)

    def stop_all_without_input_detector(self) -> None:
        msg = SystemMessageUtil.compose_stop()
        for connection in PipeManager().all_parents_without_input_detector:
            connection.send(msg)

    def quit_all(self) -> None:
        msg = SystemMessageUtil.compose_quit()
        for service in PipeManager().all_parents:
            service.send(msg)

    def join_all(self) -> None:
        self._input_detector_service.join()
        self._anemometer_service.join()
        self._compass_service.join()
