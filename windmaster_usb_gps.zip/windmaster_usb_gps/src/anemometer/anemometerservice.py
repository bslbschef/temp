from datetime import datetime
import logging
import threading
import time
from multiprocessing.connection import Connection
from threading import Thread

from baseservice import BaseService
from designpatterns.observer import Publisher, Subscriber
from serial import Serial
from storagemanager import StorageManager

from anemometer.packetextractor import PacketExtractor


class FileDumper(Subscriber):
    def __init__(self, publisher: Publisher) -> None:
        self.publisher = publisher
        self.publisher.attach(self)
        self.file = None
        file_name = StorageManager().get_current_storage_path() + "/anemometer-" + time.strftime('%Y-%m-%d_%H_%M_%S', time.localtime()) + '.txt'
        try:
            self.file = open(file_name, 'w')
        except Exception as e:
            self.file = None
            logging.error('can not create file:', str(e))

    def __del__(self) -> None:
        if self.file is not None:
            self.file.close()

    def update(self):
        rawdata = self.publisher.get_message()
        u_speed = rawdata[3: 10].decode('utf-8')
        v_speed = rawdata[11: 18].decode('utf-8')
        w_speed = rawdata[19: 26].decode('utf-8')
        self.append(u_speed, v_speed, w_speed)

    def append(self, u_speed: str, v_speed: str, w_speed: str) -> None:
        if self.file is not None:
            self.file.write(self.__compose_time_str())
            self.file.write(',')
            self.file.write(u_speed)
            self.file.write(',')
            self.file.write(v_speed)
            self.file.write(',')
            self.file.write(w_speed)
            self.file.write('\n')
            self.file.flush()

    def __compose_time_str(self) -> str:
        return datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]


class AnemometerHandler(Thread):
    def __init__(self) -> None:
        super().__init__()
        self.__running = threading.Event()
        self.__running.set()
        self.serial = None

    def run(self) -> None:
        logging.info('Thread AnemometerHandler begin to run')
        packet_extractor = PacketExtractor()
        file_dumper = FileDumper(packet_extractor)

        try:
            self.serial = Serial(port='/dev/ttyUSB0', baudrate=19200, timeout=1)
            if self.serial.is_open:
                self.serial.close()
            self.serial.open()
        except Exception as e:
            logging.error(str(e))

        while self.serial.is_open and self.__running.isSet():
            rawdata = self.serial.read(37)
            if len(rawdata) > 0:
                packet_extractor.append_rawdata(rawdata)

        self.serial.close()
        del file_dumper
        logging.info('Thread AnemometerHandler complete to run')

    def stop(self) -> None:
        self.__running.clear()


class AnemometerService(BaseService):
    def __init__(self, connection: Connection) -> None:
        super().__init__(connection)
        self._anemometerhandler = None

    def start_work(self):
        self._anemometerhandler = AnemometerHandler()
        self._anemometerhandler.start()

    def stop_work(self):
        self._anemometerhandler.stop()

    def wait_work_done(self):
        self._anemometerhandler.join()
