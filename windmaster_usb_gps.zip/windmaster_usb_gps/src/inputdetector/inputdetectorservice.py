from enum import Enum
from datetime import datetime
import logging
import threading
import time
from multiprocessing.connection import Connection
from threading import Thread

import RPi.GPIO as GPIO
from baseservice import BaseService
from utils.component_message_util import ComponentMessageUtil


class WorkingStatus(Enum):
    Initial = 0
    Working = 1
    Ended = 2


class InputDetectorHandler(Thread):
    def __init__(self, connection: Connection) -> None:
        super().__init__()
        self.__running = threading.Event()
        self.__running.set()
        self.__connection = connection
        # GPIO.setmode(GPIO.BOARD)
        # GPIO.setup(31, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
        # GPIO.add_event_detect(31, GPIO.BOTH, callback=self.edge_callback)
        # self._working_status = WorkingStatus.Initial
        self._working_status = WorkingStatus.Working
        logging.info('rising edge : %s' % str(datetime.now().strftime('%H:%M:%S.%f')[:-3]))
        self.__connection.send(ComponentMessageUtil.compose_start())

    def run(self) -> None:
        logging.info('Thread InputDetectorHandler begin to run')
        while self.__running.is_set():
            time.sleep(1)
        logging.info('Thread InputDetectorHandler complete to run')

    # def edge_callback(self, channel):
    #     logging.info('Edge detected on channle %s' % channel)
    #     time.sleep(0.1)
    #     if GPIO.input(channel) == GPIO.HIGH and self._working_status != WorkingStatus.Working:
    #         self._working_status = WorkingStatus.Working
    #         logging.info('rising edge : %s' % str(datetime.now().strftime('%H:%M:%S.%f')[:-3]))
    #         self.__connection.send(ComponentMessageUtil.compose_start())
    #     elif GPIO.input(channel) == GPIO.LOW and self._working_status == WorkingStatus.Working:
    #         self._working_status = WorkingStatus.Ended
    #         logging.info('falling edge : %s' % str(datetime.now().strftime('%H:%M:%S.%f')[:-3]))
    #         self.__connection.send(ComponentMessageUtil.compose_stop())
    #     else:
    #         logging.warning('trigger signal jitter detected : %s' % str(datetime.now().strftime('%H:%M:%S.%f')[:-3]))

    def stop(self) -> None:
        self.__running.clear()


class InputDetectorService(BaseService):
    def __init__(self, connection: Connection) -> None:
        super().__init__(connection)
        self.__inputdetector_handler = None

    def start_work(self):
        self.__inputdetector_handler = InputDetectorHandler(self.connection)
        self.__inputdetector_handler.start()

    def stop_work(self):
        self.__inputdetector_handler.stop()

    def wait_work_done(self):
        self.__inputdetector_handler.join()
