from enum import Enum
from typing import Any


class ComponentOperationType(Enum):
    UNKNOWN = -1,
    START = 1,
    STOP = 2,


class ComponentMessageUtil(object):

    template = {
        'type': 'COMPONENT',
        'operation': ComponentOperationType.UNKNOWN
    }

    @classmethod
    def is_valid(cls, message: Any) -> bool:
        return ('type' in message and message['type'] == 'COMPONENT'
                and 'operation' in message)

    @classmethod
    def compose_start(cls) -> dict:
        message = cls.template
        message['operation'] = ComponentOperationType.START
        return message

    @classmethod
    def compose_stop(cls) -> dict:
        message = cls.template
        message['operation'] = ComponentOperationType.STOP
        return message

    @classmethod
    def get_operation_type(cls, message: Any) -> ComponentOperationType:
        if cls.is_valid(message):
            return message['operation']
        else:
            return ComponentOperationType.UNKNOWN
