from enum import Enum
from typing import Any


class SystemOperationType(Enum):
    UNKNOWN = -1,
    START = 1,
    STOP = 2,
    QUIT = 3


class SystemMessageUtil(object):

    template = {
        'type': 'SYSTEM',
        'operation': SystemOperationType.UNKNOWN
    }

    @classmethod
    def is_valid(cls, message: Any) -> bool:
        return ('type' in message and message['type'] == 'SYSTEM' and 'operation' in message)

    @classmethod
    def compose_start(cls) -> dict:
        message = cls.template
        message['operation'] = SystemOperationType.START
        return message

    @classmethod
    def compose_stop(cls) -> dict:
        message = cls.template
        message['operation'] = SystemOperationType.STOP
        return message

    @classmethod
    def compose_quit(cls) -> dict:
        message = cls.template
        message['operation'] = SystemOperationType.QUIT
        return message

    @classmethod
    def get_operation_type(cls, message: Any) -> SystemOperationType:
        if cls.is_valid(message):
            return message['operation']
        else:
            return SystemOperationType.UNKNOWN
