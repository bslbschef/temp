from datetime import datetime
import logging
import threading
import time
from multiprocessing.connection import Connection
from threading import Thread
import binascii
from baseservice import BaseService
from designpatterns.observer import Publisher, Subscriber
from serial import Serial
from storagemanager import StorageManager

from digitalcompass.packetextractor import PacketExtractor


class FileDumper(Subscriber):
    def __init__(self, publisher: Publisher) -> None:
        self.publisher = publisher
        self.publisher.attach(self)
        self.file = None
        file_name = StorageManager().get_current_storage_path() + "/digitalcompass-" + time.strftime(
            '%Y-%m-%d_%H_%M_%S', time.localtime()) + '.txt'
        try:
            self.file = open(file_name, 'w')
        except Exception as e:
            self.file = None
            logging.error('can not create file:', str(e))

    def __del__(self) -> None:
        if self.file is not None:
            self.file.close()

    def update(self):
        rawdata1 = self.publisher.get_message()
        rawdata = binascii.hexlify(rawdata1)
        x_anglefin=''
        y_anglefin=''
        tem_insidefin=''
        x_angle = rawdata[8: 14].decode('utf-8')
        if x_angle[0] == '0':
            x_anglefin = "+" + str(x_angle[1:4]) + "." + str(x_angle[4:6])
        else:
            x_anglefin = "-" + str(x_angle[1:4]) + "." + str(x_angle[4:6])
        y_angle = rawdata[14: 20].decode('utf-8')
        if y_angle[0] == '0':
            y_anglefin = "+" + str(y_angle[1:4]) + "." + str(y_angle[4:6])
        else:
            y_anglefin = "-" + str(y_angle[1:4]) + "." + str(y_angle[4:6])
        tem_inside = rawdata[20: 26].decode('utf-8')
        if tem_inside[0] == '0':
            tem_insidefin = "+" + str(tem_inside[1:4]) + "." + str(tem_inside[4:6])
        else:
            tem_insidefin = "-" + str(tem_inside[1:4]) + "." + str(tem_inside[4:6])
        self.append(x_anglefin, y_anglefin, tem_insidefin)

    def append(self, x_angle: str, y_angle: str, tem_inside: str) -> None:
        if self.file is not None:
            self.file.write(self.__compose_time_str())
            self.file.write(',')
            self.file.write(x_angle)
            self.file.write(',')
            self.file.write(y_angle)
            self.file.write(',')
            self.file.write(tem_inside)
            self.file.write('\n')
            self.file.flush()

    def __compose_time_str(self) -> str:
        return datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]


class CompassHandler(Thread):
    def __init__(self) -> None:
        super().__init__()
        self.__running = threading.Event()
        self.__running.set()
        self.serial = None

    def run(self) -> None:
        logging.info('Thread CompassHandler begin to run')
        packet_extractor = PacketExtractor()
        file_dumper = FileDumper(packet_extractor)

        try:
            self.serial = Serial(port='/dev/ttyUSB1', baudrate=9600, timeout=1)
            if self.serial.is_open:
                self.serial.close()
            self.serial.open()
        except Exception as e:
            logging.error(str(e))

        while self.serial.is_open and self.__running.isSet():
            rawdata = self.serial.read(14)
            if len(rawdata) > 0:
                packet_extractor.append_rawdata(rawdata)

        self.serial.close()
        del file_dumper
        logging.info('Thread CompassHandler complete to run')

    def stop(self) -> None:
        self.__running.clear()


class CompassService(BaseService):
    def __init__(self, connection: Connection) -> None:
        super().__init__(connection)
        self._compasshandler = None

    def start_work(self):
        self._compasshandler = CompassHandler()
        self._compasshandler.start()

    def stop_work(self):
        self._compasshandler.stop()

    def wait_work_done(self):
        self._compasshandler.join()
