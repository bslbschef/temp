import binascii

from designpatterns.observer import Publisher
import logging


class PacketExtractor(Publisher):
    STX_VALUE = b'6'
    DATA_LEN = 14

    def __init__(self) -> None:
        super().__init__()
        self.__buffer = bytearray()

    def get_buffer(self):
        return bytes(self.__buffer)

    def append_rawdata(self, rawdata: bytes):
        self.__buffer.extend(rawdata)
        self.__process_rawdata()

    def __buffer_data_shift(self, offset: int):
        if offset <= len(self.__buffer):
            self.__buffer = self.__buffer[offset:]

    def __process_rawdata(self):
        header_index = self.__locate_packet_header()
        if header_index != -1:
            self.__buffer_data_shift(header_index)
            if len(self.__buffer) >= self.DATA_LEN:
                if self.__is_packet_valid(self.__buffer[0:self.DATA_LEN]):
                    self.add_message(self.__buffer[0:self.DATA_LEN])
                    self.notify_subscribers()
                    self.__buffer_data_shift(self.DATA_LEN)
                else:
                    self.__buffer_data_shift(1)
                self.__process_rawdata()
        else:
            self.__buffer.clear()

    def __locate_packet_header(self) -> int:
        hex_name = binascii.hexlify(self.__buffer)
        return hex_name.find(self.STX_VALUE)

    def __is_packet_valid(self, packet: bytes):
        if len(packet) != self.DATA_LEN:
            logging.error('packet len is not enough')
            return False
        return True
